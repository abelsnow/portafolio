/*
	grupo: g40
		Abel Martin Noguera Gonzalez 5596149
		Lucas Daniel Lamas Lezcano 4630144
*/

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;

public class FuncionHash {
	
	public static int calcular_hash (String s, int R){
		
		int valorHash = 0;
		
		//esquema 2^(k-1) 
		for (int k = 1; k < s.length(); k *= 2){
			valorHash = valorHash * R + (int)s.charAt(k - 1);
		}
		
		return valorHash;
	}
	
	public static void main (String[] args){
		
		// archivo donde se encuentran las palabras a mapear
		// el archivo fue modificado para que tenga el nombre 'es_Es'
		// tambien se borraron aquellas palabras que se encontraban en el encabezado
		// de modo a facilitar la lectura 
		String nombreArchivo = "es_ES.txt.dic";
		
		// nombre del archivo donde van a ir las frecuencias obtenidas
		// se encuentra en formato csv para luego graficarlas en excel
		String archivoDatos = "frecuencias.csv";
		
		try(BufferedReader reader = new BufferedReader(new FileReader(nombreArchivo));
			FileWriter writer = new FileWriter(archivoDatos)){
			writer.write("valor hash, frecuencia\n");
			
			String line;
			
			while((line = reader.readLine()) != null){
				String [] parts = line.split("/");
				String palabra = parts[0];
				
				int[] valores_R = {31, 37, 32, 64};
				
				for(int R : valores_R){
					
					int valor_Hash = calcular_hash(palabra, R);
					writer.write(valor_Hash + ", 1\n");
					
					//System.out.println("Valor Hash de la palabra " + palabra + "y R = " + R + ": " + valor_Hash);
				}
			}
			
		} catch (IOException e){
			System.err.println("Error al leer/escribir el archivo: " + e.getMessage());
		}
	}
}