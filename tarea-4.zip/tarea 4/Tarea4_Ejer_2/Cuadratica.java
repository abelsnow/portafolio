//Grupo 40 Abel Martin Noguera Gonzalez Ci:5.596.149. TQ||Lucas Daniel Lamas Lezcano Ci 4.630.144 TR:
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class Cuadratica<T extends Comparable<T>> implements Iterable<T> {

    private T[] tabla;
    private boolean[] borrado;
    private int tamano;
    private int numElementos;
    private double factorCargaLimite = 0.75; // Factor de carga límite para activar el rehashing
    private static final int MAX_BUSQUEDA = 100; // Límite de búsqueda para evitar bucles infinitos

    public Cuadratica(int tamano) {
        this.tamano = tamano;
        tabla = (T[]) new Comparable[tamano];
        borrado = new boolean[tamano];
        numElementos = 0;
    }

    public void insertar(T elem) {
        //prguntamos si sobrepasamos el factor de carga
        if ((double) numElementos / tamano >= factorCargaLimite) {
            rehash();
        }

        int pos = hash(elem);
        int intentos = 0;
        //Si la posicion  esta ocupada hara la busqueda de la siguiente posicion libre
        while (tabla[pos] != null && !borrado[pos] && intentos < MAX_BUSQUEDA) {
            pos = (pos + intentos * intentos) % tamano;
            intentos++;
        }
        
        //Si llegamos a este punto significa que 1)No se ha sobrepasado el factor limite y 2)Se llego al maxBusqueda
        //Lo que implica que tenemos un cluster.
        if (intentos >= MAX_BUSQUEDA) {
            rehash();
        }

        tabla[pos] = elem;
        borrado[pos] = false; // Se marca como no borrado
        numElementos++;
    }

    public void eliminar(T elem) {
        int pos = buscarPosicion(elem);
        if (pos != -1) {
            borrado[pos] = true; // Marcar como borrado
            numElementos--; // Decrementar el número de elementos
        }
    }

    public T buscar(T elem) {
        int pos = hash(elem);
        while (tabla[pos] != null) {
            if (!borrado[pos] && tabla[pos].equals(elem)) {
                return tabla[pos];
            }
            pos = (pos + 1) % tamano;
        }
        return null;
    }

    private int buscarPosicion(T elem) {
        int pos = hash(elem);
        while (tabla[pos] != null) {
            if (!borrado[pos] && tabla[pos].equals(elem)) {
                return pos;
            }
            pos = (pos + 1) % tamano;
        }
        return -1; // Elemento no encontrado
    }

    private int hash(T elem) {
        return Math.abs(elem.hashCode() % tamano);
    }

    private void rehash() {
        int nuevoTamano = tamano * 2; // Duplicar el tamaño de la tabla
        T[] nuevaTabla = (T[]) new Comparable[nuevoTamano];
        boolean[] nuevoBorrado = new boolean[nuevoTamano]; // Nuevo arreglo de marcadores de borrado

        // Reinsertar todos los elementos en la nueva tabla
        for (int i = 0; i < tamano; i++) {
            if (tabla[i] != null && !borrado[i]) {
                T elemento = tabla[i];
                int pos = hash(elemento);
                while (nuevaTabla[pos] != null) {
                    pos = (pos + 1) % nuevoTamano;
                }
                nuevaTabla[pos] = elemento;
                nuevoBorrado[pos] = false; // Se marca como no borrado en el nuevo arreglo
            }
        }

        // Actualizar la tabla y los marcadores de borrado
        tabla = nuevaTabla;
        borrado = nuevoBorrado;
        tamano = nuevoTamano;

        System.out.println("Rehashing completado. Nuevo tamaño de la tabla: " + tamano);
    }

    @Override
    public Iterator<T> iterator() {
        return new CuadraticaIterator();
    }

    private class CuadraticaIterator implements Iterator<T> {
        private int currentIndex = 0;

        @Override
        public boolean hasNext() {
            while (currentIndex < tabla.length && (tabla[currentIndex] == null || borrado[currentIndex])) {
                currentIndex++;
            }
            return currentIndex < tabla.length;
        }

        @Override
        public T next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            return tabla[currentIndex++];
        }
    }

    public void leer(String archivo) {
        try {
            FileReader fr = new FileReader(archivo);
            BufferedReader br = new BufferedReader(fr);
            String linea = br.readLine();
            while (linea != null) {
                String[] partes = linea.split("/");
                if (partes.length > 0) {
                    String palabra = partes[0].trim();
                    insertar((T) palabra); // Insertar la palabra en la tabla hash
                }
                linea = br.readLine();
            }
            br.close();
        } catch (IOException e) {
            System.out.println("Error al leer el archivo");
        }
    }

    public void tam() {
        System.out.println(tamano);
    }

    public static void main(String[] args) {
        Cuadratica<String> hashTable = new Cuadratica<>(101); // Crear una tabla hash de tamaño 101
        long inicioInsercion = System.currentTimeMillis();
        // Leer elementos desde un archivo
       hashTable.leer("es_Es.dic");
        long finInsercion = System.currentTimeMillis();
        // Imprimir la tabla completa
        System.out.println("Tabla completa:");
        hashTable.tam();
        long tiempoInsersion = finInsercion - inicioInsercion;


        // Medir el tiempo de búsqueda de todos los elementos
        long inicioBusqueda = System.currentTimeMillis();
        for (String palabra : hashTable) {
            hashTable.buscar(palabra); // buscar la palabra
        }
        long finBusqueda = System.currentTimeMillis();
        long tiempoBusqueda = finBusqueda - inicioBusqueda;

        // Medir el tiempo de eliminación de todos los elementos
        long inicioBorrado = System.currentTimeMillis();
        for (String palabra : hashTable) {
            hashTable.eliminar(palabra); // eliminar la palabra
        }
        long finBorrado = System.currentTimeMillis();
        long tiempoBorrado = finBorrado - inicioBorrado;

        // Imprimir los tiempos
        System.out.println("Dispersion cuadrática:");
        System.out.println("------------------------------------------------------");
        System.out.println("|     Insersion     |     Busqueda     |     Borrado  |");
        System.out.println("------------------------------------------------------");
        System.out.printf("|       %d ms      |    %d    ms     |    %d ms  |\n", tiempoInsersion, tiempoBusqueda, tiempoBorrado);
        System.out.println("------------------------------------------------------");
    }
}
