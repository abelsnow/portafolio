//Grupo 40 Abel Martin Noguera Gonzalez Ci:5.596.149. TQ||Lucas Daniel Lamas Lezcano Ci 4.630.144 TR:
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class HashAbierto<T extends Comparable<T>> implements Iterable<T> {

    private Object[] tabla; // Cambio de Lista[] a Object[]
    private int tamano;
    private int numElementos;
    private int colisiones;

    public HashAbierto(int tamano) {
        this.tamano = tamano;
        tabla = new Object[tamano]; // Cambio aquí también
        for (int i = 0; i < tamano; i++) {
            tabla[i] = new Lista(); // Se mantienen las instancias de Lista en cada posición
        }
        numElementos = 0;
        colisiones = 0;
    }

    private class Lista implements Iterable<T> {
        private Nodo primero;

        public Lista() {
            primero = null;
        }

        public void agregar(T dato) {
            Nodo nuevoNodo = new Nodo(dato);
            nuevoNodo.siguiente = primero;
            primero = nuevoNodo;
        }

        public void remover(T dato) {
            if (primero != null) {
                if (primero.dato.equals(dato)) {
                    primero = primero.siguiente;
                    return;
                }
                Nodo anterior = primero;
                Nodo actual = primero.siguiente;
                while (actual != null) {
                    if (actual.dato.equals(dato)) {
                        anterior.siguiente = actual.siguiente;
                        return;
                    }
                    anterior = actual;
                    actual = actual.siguiente;
                }
            }
        }

        public boolean contiene(T dato) {
            Nodo actual = primero;
            while (actual != null) {
                if (actual.dato.equals(dato)) {
                    return true;
                }
                actual = actual.siguiente;
            }
            return false;
        }

        public boolean esVacia() {
            return primero == null;
        }

        public Iterator<T> iterator() {
            return new ListaIterator();
        }

        private class ListaIterator implements Iterator<T> {
            private Nodo actual = primero;

            @Override
            public boolean hasNext() {
                return actual != null;
            }

            @Override
            public T next() {
                if (!hasNext()) {
                    throw new NoSuchElementException("No hay más elementos en la lista");
                }
                T dato = actual.dato;
                actual = actual.siguiente;
                return dato;
            }
        }
    }

    private class Nodo {
        T dato;
        Nodo siguiente;

        public Nodo(T dato) {
            this.dato = dato;
            this.siguiente = null;
        }
    }

    public void insertar(T elem) {
        int pos = hash(elem);
        if (!getLista(pos).contiene(elem)) { // Cambio de tabla[pos] a getLista(pos)
            getLista(pos).agregar(elem); // Cambio de tabla[pos] a getLista(pos)
            numElementos++;
        } else {
            colisiones++;
        }
    }

    public void eliminar(T elem) {
        int pos = hash(elem);
        getLista(pos).remover(elem); // Cambio de tabla[pos] a getLista(pos)
        if (getLista(pos).esVacia()) { // Cambio de tabla[pos] a getLista(pos)
            numElementos--;
        }
    }

    public T buscar(T elem) {
        int pos = hash(elem);
        for (T obj : getLista(pos)) { // Cambio de tabla[pos] a getLista(pos)
            if (obj.equals(elem)) {
                return obj;
            }
        }
        return null;
    }

    private int hash(T elem) {
        return Math.abs(elem.hashCode() % tamano);
    }

    public void imprimir() {
        for (int i = 0; i < tamano; i++) {
            if (!getLista(i).esVacia()) { // Cambio de tabla[i] a getLista(i)
                System.out.println("Posición " + i + ":");
                for (T dato : getLista(i)) { // Cambio de tabla[i] a getLista(i)
                    System.out.println(dato);
                }
            }
        }
    }

    public int tam() {
        return numElementos;
    }

    public void leer(String archivo) {
        try {
            FileReader fr = new FileReader(archivo);
            BufferedReader br = new BufferedReader(fr);
            String linea = br.readLine();
            while (linea != null) {
                String[] partes = linea.split("/");
                if (partes.length > 0) {
                    String palabra = partes[0].trim();
                    insertar((T) palabra); // Insertar la palabra en la tabla hash
                }
                linea = br.readLine();
            }
            br.close();
        } catch (IOException e) {
            System.out.println("Error al leer el archivo");
        }
    }

    @Override
    public Iterator<T> iterator() {
        return new HashIterator();
    }

    private class HashIterator implements Iterator<T> {
        private int indiceLista = 0;
        private int indiceTabla = 0;
        private Iterator<T> iteradorListaActual;

        @Override
        public boolean hasNext() {
            // Verificar si hay elementos en la lista actual
            if (iteradorListaActual != null && iteradorListaActual.hasNext()) {
                return true;
            }

            // Ir a la siguiente lista no vacía en la tabla hash
            while (indiceTabla < tamano && getLista(indiceTabla).esVacia()) { // Cambio de tabla[indiceTabla] a getLista(indiceTabla)
                indiceTabla++;
            }

            // Revisa si se llegó al final de la tabla
            return indiceTabla < tamano;
        }

        @Override
        public T next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }

            // Obtener el siguiente elemento de la lista actual
            if (iteradorListaActual == null || !iteradorListaActual.hasNext()) {
                iteradorListaActual = getLista(indiceTabla).iterator(); // Cambio de tabla[indiceTabla] a getLista(indiceTabla)
                indiceLista = 0;
            }
            indiceLista++;
            return iteradorListaActual.next();
        }
    }

    // Método privado para obtener la lista en la posición dada
    private Lista getLista(int pos) {
        return (Lista) tabla[pos]; // Hacemos un cast a Lista
    }

    public static void main(String[] args) {
        HashAbierto<String> hashTable = new HashAbierto<>(1000);
        // Leer elementos desde un archivo
        long inicioInsercion = System.currentTimeMillis();
        hashTable.leer("es_Es.dic");
        long finInsercion = System.currentTimeMillis();
        long tiempoInsersion = finInsercion - inicioInsercion;

        // Medir el tiempo de búsqueda de todos los elementos
        long inicioBusqueda = System.currentTimeMillis();
        for (int i = 0; i < hashTable.tamano; i++) {
            for (String palabra : hashTable.getLista(i)) {
                hashTable.buscar(palabra);
            }
        }
        long finBusqueda = System.currentTimeMillis();
        long tiempoBusqueda = finBusqueda - inicioBusqueda;

        // Medir el tiempo de eliminación de todos los elementos
        long inicioBorrado = System.currentTimeMillis();
        for (int i = 0; i < hashTable.tamano; i++) {
            for (String palabra : hashTable.getLista(i)) {
                hashTable.eliminar(palabra);
            }
        }
        long finBorrado = System.currentTimeMillis();
        long tiempoBorrado = finBorrado - inicioBorrado;

        // Imprimir los tiempos
        System.out.println("Dispersion Abierta:");
        System.out.println("------------------------------------------------------");
        System.out.println("|     Insersion     |     Busqueda     |     Borrado  |");
        System.out.println("------------------------------------------------------");
        System.out.printf("|       %d ms      |    %d    ms     |    %d ms  |\n", tiempoInsersion, tiempoBusqueda, tiempoBorrado);
        System.out.println("------------------------------------------------------");
    }
}
