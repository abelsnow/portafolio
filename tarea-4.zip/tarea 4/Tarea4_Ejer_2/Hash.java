//Grupo 40 Abel Martin Noguera Gonzalez Ci:5.596.149. TQ||Lucas Daniel Lamas Lezcano Ci 4.630.144 TR:
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class Hash<T extends Comparable<T>> implements Iterable<T> {

    private T[] tabla;
    private int tamano;
    private int numElementos;
    private double factorCargaLimite = 0.75; // Factor de carga límite para activar el rehashing
    private static final int MAX_BUSQUEDA = 1000; // Límite de búsqueda para evitar bucles infinitos

    public Hash(int tamano) {
        this.tamano = tamano;
        tabla = (T[]) new Comparable[tamano];
        numElementos = 0;
    }

    public void insertar(T elem) {
        if ((double) numElementos / tamano >= factorCargaLimite) {
            rehash();
        }

        int pos = hash(elem);
        int intentos = 0;
        while (tabla[pos] != null && intentos < MAX_BUSQUEDA) {
            pos = (pos + 1) % tamano;
            intentos++;
        }

        if (intentos >= MAX_BUSQUEDA) {
            rehash();
            insertar(elem); // Reintentar la inserción después de rehashing
            return;
        }

        tabla[pos] = elem;
        numElementos++;
    }

    // Eliminación lineal (página 303, CLRS 4ta edición)
    
    public void eliminar(T elem) {
        int pos = buscarPosicion(elem);
        if (pos != -1) {
            // Eliminar directamente el elemento
            tabla[pos] = null;
            numElementos--;

            // Reorganizar la tabla si es necesario
            int siguiente = (pos + 1) % tamano;
            while (tabla[siguiente] != null) {
                T temp = tabla[siguiente];
                tabla[siguiente] = null;
                tabla[pos] = temp;
                pos = siguiente;
                siguiente = (siguiente + 1) % tamano;
            }
        }
    }

    public T buscar(T elem) {
        int pos = hash(elem);
        while (tabla[pos] != null) {
            if (tabla[pos].equals(elem)) {
                return tabla[pos];
            }
            pos = (pos + 1) % tamano;
        }
        return null;
    }

    private int buscarPosicion(T elem) {
        int pos = hash(elem);
        while (tabla[pos] != null) {
            if (tabla[pos].equals(elem)) {
                return pos;
            }
            pos = (pos + 1) % tamano;
        }
        return -1; // Elemento no encontrado
    }

    public void leer(String archivo) {
        try {
            FileReader fr = new FileReader(archivo);
            BufferedReader br = new BufferedReader(fr);
            String linea = br.readLine();
            while (linea != null) {
                String[] partes = linea.split("/");
                if (partes.length > 0) {
                    String palabra = partes[0].trim();
                    insertar((T) palabra); // Insertar la palabra en la tabla hash
                }
                linea = br.readLine();
            }
            br.close();
        } catch (IOException e) {
            System.out.println("Error al leer el archivo");
        }
    }

    private int hash(T elem) {
        return Math.abs(elem.hashCode() % tamano);
    }

    
    public void imprimir() {
        for (int i = 0; i < tabla.length; i++) {
            if (tabla[i] != null) {
                System.out.println(tabla[i]);
            }
        }
    }

    private void rehash() {
        int nuevoTamano = tamano * 2; // Duplicar el tamaño de la tabla
        T[] nuevaTabla = (T[]) new Comparable[nuevoTamano];

        // Reinsertar todos los elementos en la nueva tabla
        for (int i = 0; i < tamano; i++) {
            if (tabla[i] != null) {
                T elemento = tabla[i];
                int pos = hash(elemento);
                while (nuevaTabla[pos] != null) {
                    pos = (pos + 1) % nuevoTamano;
                }
                nuevaTabla[pos] = elemento;
            }
        }

        // Actualizar la tabla con la nueva tabla y el nuevo tamaño
        tabla = nuevaTabla;
        tamano = nuevoTamano;

        
    }

    @Override
    public Iterator<T> iterator() {
        return new HashIterator();
    }

    private class HashIterator implements Iterator<T> {
        private int currentIndex = 0;

        @Override
        public boolean hasNext() {
            while (currentIndex < tabla.length && tabla[currentIndex] == null) {
                currentIndex++;
            }
            return currentIndex < tabla.length;
        }

        @Override
        public T next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            return tabla[currentIndex++];
        }
    }

    public static void main(String[] args) {
        Hash<String> hashTable = new Hash<>(100); // Crear una tabla hash de tamaño 100
        long inicioInsercion = System.currentTimeMillis();
        // Leer elementos desde un archivo
        hashTable.leer("es_Es.dic");
        long finInsercion = System.currentTimeMillis();
        
        
        long tiempoInsersion = finInsercion - inicioInsercion;


        // Medir el tiempo de búsqueda de todos los elementos
        long inicioBusqueda = System.currentTimeMillis();
        for (String palabra : hashTable) {
            hashTable.buscar(palabra); // Simplemente buscar la palabra
        }
        long finBusqueda = System.currentTimeMillis();
        long tiempoBusqueda = finBusqueda - inicioBusqueda;

        // Medir el tiempo de eliminación de todos los elementos
        long inicioBorrado = System.currentTimeMillis();
        for (String palabra : hashTable) {
            hashTable.eliminar(palabra); // Simplemente eliminar la palabra
        }
        long finBorrado = System.currentTimeMillis();
        long tiempoBorrado = finBorrado - inicioBorrado;

        // Imprimir los tiempos
        System.out.println("Dispersion cerrada Lineal:");
        System.out.println("------------------------------------------------------");
        System.out.println("|     Insersion     |     Busqueda     |     Borrado  |");  
        System.out.println("------------------------------------------------------");
        System.out.printf("|       %d ms      |    %d    ms     |    %d ms  |\n", tiempoInsersion, tiempoBusqueda, tiempoBorrado);
        System.out.println("------------------------------------------------------");                             
    }
}
